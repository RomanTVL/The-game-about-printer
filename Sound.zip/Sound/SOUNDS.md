# Petya's Printer (incremental, 2100) — sound kit

Copied from the library (originals untouched). Rebuild with `python -I _tools/make_game_kit.py . _tools/kits/petya_printer.py`.


## 01_printer_movement
| file | from pack | license |
|---|---|---|
| `ROBOTIC_Transformation_Insect_01_Servos_Clicks_Digital_stere.wav` | Robotic Transformations | CC-BY 4.0; CC-BY 3.0; CC-BY-SA 4.0; CC-B |
| `ROBOTIC_Transformation_Insect_02_Servos_Clicks_Digital_stere.wav` | Robotic Transformations | CC-BY 4.0; CC-BY 3.0; CC-BY-SA 4.0; CC-B |
| `gear01.wav` | Some sounds | CC0 |
| `gear02.wav` | Some sounds | CC0 |
| `gear03.wav` | Some sounds | CC0 |
| `gear04.wav` | Some sounds | CC0 |
| `nema17_01mm.wav` | Stepper Motor Pack 1 | CC-BY 3.0 |
| `nema17_10mm.wav` | Stepper Motor Pack 1 | CC-BY 3.0 |
| `nema17_1mm.wav` | Stepper Motor Pack 1 | CC-BY 3.0 |
| `printhead_move_01_short_fast.wav` | Print Head Stepper Moves | CC0 |
| `printhead_move_02_short_slow.wav` | Print Head Stepper Moves | CC0 |
| `printhead_move_03_long_sweep.wav` | Print Head Stepper Moves | CC0 |
| `printhead_move_04_back_forth.wav` | Print Head Stepper Moves | CC0 |
| `printhead_move_05_two_axis.wav` | Print Head Stepper Moves | CC0 |
| `printhead_move_06_zigzag_infill.wav` | Print Head Stepper Moves | CC0 |
| `printhead_move_07_heavy_z_axis.wav` | Print Head Stepper Moves | CC0 |
| `printhead_move_08_homing.wav` | Print Head Stepper Moves | CC0 |
| `robotics1.wav` | Sound Effects Pack | CC0 |
| `robotics2.wav` | Sound Effects Pack | CC0 |

## 02_typewriter_printing
| file | from pack | license |
|---|---|---|
| `typewriter.wav` | Mechanical Sounds | CC0 |
| `typewriter1.wav` | Typewriter sounds | CC0 |
| `typewriter2.wav` | Typewriter sounds | CC0 |
| `typewriter3.wav` | Typewriter sounds | CC0 |
| `typewriter4.wav` | Typewriter sounds | CC0 |
| `typewriter5.wav` | Typewriter sounds | CC0 |
| `typewriter6.wav` | Typewriter sounds | CC0 |
| `typewriter7.wav` | Typewriter sounds | CC0 |
| `typewriter8.wav` | Typewriter sounds | CC0 |

## 03_camera_photo
| file | from pack | license |
|---|---|---|
| `Camera_01.wav` | 202 More Sound Effects | CC0 |
| `Camera_02.wav` | 202 More Sound Effects | CC0 |
| `Camera_03.wav` | 202 More Sound Effects | CC0 |
| `camera_0.ogg` | CameraShudder | CC0 |
| `photo.ogg` | Camera | CC0 |

## 04_bolts_metal_assembly
| file | from pack | license |
|---|---|---|
| `MECHMisc_TRS_Cable_Plug_In_Solid_Metal_Thump_BOLT_ARP2600.wav` | Bolt - ARP 2600- Droids, Blips, Drones & more | Sonniss GDC royalty-free (commercial OK, |
| `TOOLHand_Bar_Clamp_Screw_Tighten_UberDuo_TOOL.wav` | UberDuo - The Workshop Audio Playset | Sonniss GDC royalty-free (commercial OK, |
| `TOOLHand_Staple_Gun_UberDuo_TOOL.wav` | UberDuo - The Workshop Audio Playset | Sonniss GDC royalty-free (commercial OK, |
| `bing1.wav` | Metal Impact Sounds | CC0 |
| `clank1.wav` | Mechanical Sounds | CC0 |
| `clink1_0.wav` | Metal Impact Sounds | CC0 |
| `clink2.wav` | Metal Impact Sounds | CC0 |
| `clink3.wav` | Metal Impact Sounds | CC0 |
| `lightclunk1.wav` | Mechanical Sounds | CC0 |
| `lightclunk2.wav` | Mechanical Sounds | CC0 |
| `mechanical1.wav` | Mechanical Sounds | CC0 |
| `mechanical2.wav` | Mechanical Sounds | CC0 |
| `metal_hit_01.ogg` | 100 CC0 metal and wood SFX | CC0 |
| `metal_hit_02.ogg` | 100 CC0 metal and wood SFX | CC0 |
| `metal_hit_03.ogg` | 100 CC0 metal and wood SFX | CC0 |
| `metal_hit_04.ogg` | 100 CC0 metal and wood SFX | CC0 |
| `metal_hit_05.ogg` | 100 CC0 metal and wood SFX | CC0 |
| `squeakyclick1.wav` | Mechanical Sounds | CC0 |
| `squeakyclick2.wav` | Mechanical Sounds | CC0 |
| `workshop_-_clink.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_clink1.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_clink2.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_clink3.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_clink_thud.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_drill_short_1.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_drill_short_2.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_dull_ping.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_dull_pings.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_dull_pings_2.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_dull_pings_3.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_dull_pings_4.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_metal_drop.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_metal_drop_2.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_metal_drop_3.wav` | 68 Workshop Sounds | CC0 |
| `workshop_-_metal_tapping.wav` | 68 Workshop Sounds | CC0 |

## 05_ui_clicks
| file | from pack | license |
|---|---|---|
| `Click_Electronic_00.mp3` | UI Sound Effects Library | CC-BY 3.0 |
| `Click_Electronic_01.mp3` | UI Sound Effects Library | CC-BY 3.0 |
| `Click_Electronic_02.mp3` | UI Sound Effects Library | CC-BY 3.0 |
| `Click_Electronic_03.mp3` | UI Sound Effects Library | CC-BY 3.0 |
| `Click_Electronic_04.mp3` | UI Sound Effects Library | CC-BY 3.0 |
| `Click_Electronic_05.mp3` | UI Sound Effects Library | CC-BY 3.0 |
| `Click_Soft_00.mp3` | UI Sound Effects Library | CC-BY 3.0 |
| `Click_Soft_01.mp3` | UI Sound Effects Library | CC-BY 3.0 |
| `Click_Soft_02.mp3` | UI Sound Effects Library | CC-BY 3.0 |
| `back_001.ogg` | Interface Sounds | CC0 |
| `back_002.ogg` | Interface Sounds | CC0 |
| `back_003.ogg` | Interface Sounds | CC0 |
| `back_004.ogg` | Interface Sounds | CC0 |
| `click_001.ogg` | Interface Sounds | CC0 |
| `click_002.ogg` | Interface Sounds | CC0 |
| `click_003.ogg` | Interface Sounds | CC0 |
| `click_004.ogg` | Interface Sounds | CC0 |
| `close_001.ogg` | Interface Sounds | CC0 |
| `close_002.ogg` | Interface Sounds | CC0 |
| `close_003.ogg` | Interface Sounds | CC0 |
| `close_004.ogg` | Interface Sounds | CC0 |
| `confirmation_001.ogg` | Interface Sounds | CC0 |
| `confirmation_002.ogg` | Interface Sounds | CC0 |
| `confirmation_003.ogg` | Interface Sounds | CC0 |
| `confirmation_004.ogg` | Interface Sounds | CC0 |
| `maximize_001.ogg` | Interface Sounds | CC0 |
| `maximize_002.ogg` | Interface Sounds | CC0 |
| `maximize_003.ogg` | Interface Sounds | CC0 |
| `maximize_004.ogg` | Interface Sounds | CC0 |
| `minimize_001.ogg` | Interface Sounds | CC0 |
| `minimize_002.ogg` | Interface Sounds | CC0 |
| `minimize_003.ogg` | Interface Sounds | CC0 |
| `minimize_004.ogg` | Interface Sounds | CC0 |

## 06_ui_errors
| file | from pack | license |
|---|---|---|
| `error_001.ogg` | Interface Sounds | CC0 |
| `error_002.ogg` | Interface Sounds | CC0 |
| `error_003.ogg` | Interface Sounds | CC0 |
| `error_004.ogg` | Interface Sounds | CC0 |
| `error_005.ogg` | Interface Sounds | CC0 |
| `error_006.ogg` | Interface Sounds | CC0 |

## 07_money_coins
| file | from pack | license |
|---|---|---|
| `Coins_Few_00.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Few_01.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Few_02.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Few_03.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Few_04.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Few_05.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Pouring_00.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Pouring_01.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Pouring_02.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Pouring_03.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Several_00.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Several_01.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Several_02.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Several_03.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Single_00.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Single_01.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Single_02.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Single_03.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Single_04.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `Coins_Single_05.mp3` | Coins Sound Effects Library | CC-BY 3.0 |
| `coin-spin-fall-01.wav` | Fantasy Sound Effects (Tinysized SFX) | CC0 |
| `coinflip-01.wav` | Fantasy Sound Effects (Tinysized SFX) | CC0 |
| `coins-shake-01.wav` | Fantasy Sound Effects (Tinysized SFX) | CC0 |

## 08_upgrade_levelup_unlock
| file | from pack | license |
|---|---|---|
| `Chime_Cancel.mp3` | Chimey UI Sounds | CC0 |
| `Chime_Confirm.mp3` | Chimey UI Sounds | CC0 |
| `Chime_Exit.mp3` | Chimey UI Sounds | CC0 |
| `Chime_LevelUp.mp3` | Chimey UI Sounds | CC0 |
| `Chime_Load.mp3` | Chimey UI Sounds | CC0 |
| `Chime_Save.mp3` | Chimey UI Sounds | CC0 |
| `Chime_Sleep.mp3` | Chimey UI Sounds | CC0 |
| `Jingle_Achievement_00.mp3` | Sci-Fi Sound Effects Library | CC-BY 3.0 |
| `Jingle_Win_00.mp3` | Sci-Fi Sound Effects Library | CC-BY 3.0 |
| `Jingle_Win_01.mp3` | Sci-Fi Sound Effects Library | CC-BY 3.0 |
| `Powerup.ogg` | 100 plus game sound effects WAV,OGG,M4A | CC-BY 3.0 |
| `Powerup2.ogg` | 100 plus game sound effects WAV,OGG,M4A | CC-BY 3.0 |
| `Powerup3.ogg` | 100 plus game sound effects WAV,OGG,M4A | CC-BY 3.0 |
| `Powerup4.ogg` | 100 plus game sound effects WAV,OGG,M4A | CC-BY 3.0 |
| `Powerup5.ogg` | 100 plus game sound effects WAV,OGG,M4A | CC-BY 3.0 |
| `Robot_Activated_00.mp3` | Sci-Fi Sound Effects Library | CC-BY 3.0 |

## 09_notifications_beeps
| file | from pack | license |
|---|---|---|
| `beep-00.wav` | Interface beeps | CC0 |
| `beep-01.wav` | Interface beeps | CC0 |
| `beep-02.wav` | Interface beeps | CC0 |
| `beep-03.wav` | Interface beeps | CC0 |
| `beep-04.wav` | Interface beeps | CC0 |
| `beep-05.wav` | Interface beeps | CC0 |
| `beep-06.wav` | Interface beeps | CC0 |
| `beep-07.wav` | Interface beeps | CC0 |
| `beep-08.wav` | Interface beeps | CC0 |
| `beep-09.wav` | Interface beeps | CC0 |

## 10_laptop_ai_terminal
| file | from pack | license |
|---|---|---|
| `Robot_Talk_00.mp3` | Sci-Fi Sound Effects Library | CC-BY 3.0 |
| `Robot_Talk_01.mp3` | Sci-Fi Sound Effects Library | CC-BY 3.0 |
| `Robot_Talk_02.mp3` | Sci-Fi Sound Effects Library | CC-BY 3.0 |
| `beep_01.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `beep_02.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `beep_03.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `generated-003_slow.wav` | Keyboard Soundpack #1 [Typing and Single Keystrokes] | CC0 |
| `generated-004_medium.wav` | Keyboard Soundpack #1 [Typing and Single Keystrokes] | CC0 |
| `generated-005_fast.wav` | Keyboard Soundpack #1 [Typing and Single Keystrokes] | CC0 |
| `keypress-001.wav` | Keyboard Soundpack #1 [Typing and Single Keystrokes] | CC0 |
| `keypress-002.wav` | Keyboard Soundpack #1 [Typing and Single Keystrokes] | CC0 |
| `keypress-003.wav` | Keyboard Soundpack #1 [Typing and Single Keystrokes] | CC0 |
| `keypress-004.wav` | Keyboard Soundpack #1 [Typing and Single Keystrokes] | CC0 |
| `keypress-005.wav` | Keyboard Soundpack #1 [Typing and Single Keystrokes] | CC0 |
| `keypress-006.wav` | Keyboard Soundpack #1 [Typing and Single Keystrokes] | CC0 |
| `terminal_01.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `terminal_02.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `terminal_03.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `terminal_04.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `terminal_05.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `terminal_06.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `terminal_07.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `terminal_08.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `terminal_09.ogg` | 50 CC0 Sci-Fi SFX | CC0 |

## 11_story_plastic_toys
| file | from pack | license |
|---|---|---|
| `Plastic_01.wav` | 202 More Sound Effects | CC0 |
| `Plastic_02.wav` | 202 More Sound Effects | CC0 |
| `Plastic_03.wav` | 202 More Sound Effects | CC0 |
| `Plastic_04.wav` | 202 More Sound Effects | CC0 |
| `Plastic_05.wav` | 202 More Sound Effects | CC0 |
| `Plastic_06.wav` | 202 More Sound Effects | CC0 |
| `Plastic_07.wav` | 202 More Sound Effects | CC0 |
| `Plastic_08.wav` | 202 More Sound Effects | CC0 |
| `squeak_toy_-_squeak1.wav` | Squeak toy sounds | CC0 |
| `squeak_toy_-_squeak2.wav` | Squeak toy sounds | CC0 |
| `squeak_toy_-_squeak3.wav` | Squeak toy sounds | CC0 |
| `squeak_toy_-_squeak5.wav` | Squeak toy sounds | CC0 |

## 12_story_uncle_letter
| file | from pack | license |
|---|---|---|
| `paper_crushed_-_1.mp3` | Various Paper Sound Effects | CC0 |
| `paper_crushed_-_2.mp3` | Various Paper Sound Effects | CC0 |
| `paper_ripped_-_1.mp3` | Various Paper Sound Effects | CC0 |
| `paper_sound_-_1.mp3` | Various Paper Sound Effects | CC0 |
| `paper_sound_-_2.mp3` | Various Paper Sound Effects | CC0 |
| `paper_sound_-_3.mp3` | Various Paper Sound Effects | CC0 |
| `paper_sound_-_4.mp3` | Various Paper Sound Effects | CC0 |

## 13_story_flashbacks
| file | from pack | license |
|---|---|---|
| `gunshot_1.wav` | Gunshots! | CC-BY 3.0 |
| `gunshot_2.wav` | Gunshots! | CC-BY 3.0 |
| `gunshot_3.wav` | Gunshots! | CC-BY 3.0 |
| `gunshot_4.wav` | Gunshots! | CC-BY 3.0 |
| `gunshot_5.wav` | Gunshots! | CC-BY 3.0 |
| `gunshot_6.wav` | Gunshots! | CC-BY 3.0 |
| `qubodup-crash.ogg` | Crash Collision | CC0 |

## 14_air_swimming_whoosh
| file | from pack | license |
|---|---|---|
| `swish-1.wav` | Swishes Sound Pack | CC0 |
| `swish-2.wav` | Swishes Sound Pack | CC0 |
| `swish-3.wav` | Swishes Sound Pack | CC0 |
| `swish-4.wav` | Swishes Sound Pack | CC0 |
| `swish-5.wav` | Swishes Sound Pack | CC0 |
| `swish-6.wav` | Swishes Sound Pack | CC0 |
| `swish-7.wav` | Swishes Sound Pack | CC0 |
| `swish-8.wav` | Swishes Sound Pack | CC0 |

## 15_ambience_workshop
| file | from pack | license |
|---|---|---|
| `EM_Fields_01.wav` | EM Fields Pack 1 | CC-BY 3.0 |
| `EM_Fields_02.wav` | EM Fields Pack 1 | CC-BY 3.0 |
| `EM_Fields_03.wav` | EM Fields Pack 1 | CC-BY 3.0 |
| `loop_machine_01.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `loop_machine_02.ogg` | 50 CC0 Sci-Fi SFX | CC0 |
| `loop_machine_03.ogg` | 50 CC0 Sci-Fi SFX | CC0 |

## 16_doors
| file | from pack | license |
|---|---|---|
| `Key_Lock_Door_01.wav` | 202 More Sound Effects | CC0 |
| `Key_Lock_Door_02.wav` | 202 More Sound Effects | CC0 |
| `Key_Lock_Door_03.wav` | 202 More Sound Effects | CC0 |
| `Key_Lock_Door_04.wav` | 202 More Sound Effects | CC0 |

## music_01_workshop_idle_loop
| file | from pack | license |
|---|---|---|
| `357._White_Garage_0.mp3` | White Garage | CC-BY 3.0 |
| `Time_to_business_guys.mp3` | Time to business, guys | CC-BY 3.0 |
| `chilllofir-loop.ogg` | Chill lofi inspired [loop edit] | CC0 |
| `lofiagain.ogg` | Lofi again | CC0 |
| `mocha_frapp_2.mp3` | Mocha Frapp | CC0 |
| `work1_0.mp3` | Idle Work #1 | CC0 |

## music_02_uncle_gang_noir_jazz
| file | from pack | license |
|---|---|---|
| `LD40_Heavy_Heist.ogg` | Heavy Heist | CC0 |
| `Trouble_Makers.mp3` | Trouble Makers (Cool/Riff-Jazz) | CC-BY 3.0 |
| `Trouble_Makers_Loopable.wav` | Trouble Makers (Cool/Riff-Jazz) | CC-BY 3.0 |
| `blues_0.mp3` | Jazzy blues | CC0 |
| `manwithaplan.mp3` | Man with a Plan | CC-BY 4.0 |

## music_03_sad_backstory
| file | from pack | license |
|---|---|---|
| `Piano_Loop.wav` | Emotional piano loop | CC0 |
| `WhatIsLeft_0.mp3` | Sad Scene Music (What is Left) | CC0 |

## music_04_city_2100_ai
| file | from pack | license |
|---|---|---|
| `Cyberpunk_Moonlight_Sonata_0.mp3` | Cyberpunk Moonlight Sonata | CC0 |
| `Cyberpunk_Moonlight_Sonata_v2.mp3` | Cyberpunk Moonlight Sonata | CC0 |
| `electric_city_-_part_1_loop.ogg` | Electric City | CC0 |
| `electric_city_-_part_2_loop.ogg` | Electric City | CC0 |
| `high_tech_lab.ogg` | High Tech Lab | CC-BY 4.0; CC-BY 3.0; OGA-BY 3.0 |
| `ruskerdax_-_ghosts_in_the_machine.mp3` | Ghosts in the Machine | CC0 |

## music_05_shop
| file | from pack | license |
|---|---|---|
| `Buy_Something.ogg` | Shop Theme | CC0 |
| `Buy_Something_Radio_Edit.ogg` | Shop Theme | CC0 |
| `urban_shop_bpm92.mp3` | Urban Shop | CC0 |
| `urban_shop_bpm92_0.ogg` | Urban Shop | CC0 |

## music_06_menu
| file | from pack | license |
|---|---|---|
| `007_Synthwave_421k.mp3` | Calm Relax 1 (Synthwave 421k) | CC0 |

## music_07_jingles
| file | from pack | license |
|---|---|---|
| `jingles_HIT00.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT01.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT02.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT03.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT04.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT05.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT06.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT07.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT08.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT09.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT10.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT11.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT12.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT13.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT14.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT15.ogg` | 85 Short music jingles | CC0 |
| `jingles_HIT16.ogg` | 85 Short music jingles | CC0 |
| `jingles_NES00.ogg` | 85 Short music jingles | CC0 |
| `jingles_NES01.ogg` | 85 Short music jingles | CC0 |
| `jingles_NES02.ogg` | 85 Short music jingles | CC0 |
